
      # The java implementation to use. If JAVA_HOME is not found we expect java and jar to be in path
      export JAVA_HOME=/export/cloud/jdk1.8.0_301

      # any additional java opts you want to set. This will apply to both client and server operations
      
      export ATLAS_OPTS="-Dlog4j.configuration=atlas-log4j.xml"
      

      # metadata configuration directory
      export ATLAS_CONF=/usr/hdp/current/atlas-server/conf

      # Where log files are stored. Defatult is logs directory under the base install location
      export ATLAS_LOG_DIR=/export/var/log/atlas

      # additional classpath entries
      export ATLASCPPATH= 

      # data dir
      export ATLAS_DATA_DIR=/usr/hdp/current/atlas-server/data

      # pid dir
      export ATLAS_PID_DIR=/var/run/atlas

      # hbase conf dir
      export HBASE_CONF_DIR=/etc/hbase/conf

      # Where do you want to expand the war file. By Default it is in /server/webapp dir under the base install dir.
      export ATLAS_EXPANDED_WEBAPP_DIR=/usr/hdp/current/atlas-server/server/webapp
      export ATLAS_SERVER_OPTS="-server -XX:SoftRefLRUPolicyMSPerMB=0 -XX:+CMSClassUnloadingEnabled -XX:+UseConcMarkSweepGC -XX:+CMSParallelRemarkEnabled -XX:+PrintTenuringDistribution -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=$ATLAS_LOG_DIR/atlas_server.hprof -Xloggc:$ATLAS_LOG_DIR/gc-worker.log -verbose:gc -XX:+UseGCLogFileRotation -XX:NumberOfGCLogFiles=10 -XX:GCLogFileSize=1m -XX:+PrintGCDetails -XX:+PrintHeapAtGC -XX:+PrintGCTimeStamps"
      
      export ATLAS_SERVER_HEAP="-Xms2048m -Xmx2048m -XX:MaxNewSize=600m -XX:MetaspaceSize=100m -XX:MaxMetaspaceSize=512m"
      